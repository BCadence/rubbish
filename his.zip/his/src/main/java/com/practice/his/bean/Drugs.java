package com.practice.his.bean;

public class Drugs {

    private String DrugsID;
    private String DrugsCode;
    private String DrugsName;
    private String DrugsFormat;
    private String DrugsUnit;
    private String DrugUsage;
    private String DrugsPrice;

    public String getDrugsID() {
        return DrugsID;
    }

    public void setDrugsID(String drugsID) {
        DrugsID = drugsID;
    }

    public String getDrugsCode() {
        return DrugsCode;
    }

    public void setDrugsCode(String drugsCode) {
        DrugsCode = drugsCode;
    }

    public String getDrugsName() {
        return DrugsName;
    }

    public void setDrugsName(String drugsName) {
        DrugsName = drugsName;
    }

    public String getDrugsFormat() {
        return DrugsFormat;
    }

    public void setDrugsFormat(String drugsFormat) {
        DrugsFormat = drugsFormat;
    }

    public String getDrugsUnit() {
        return DrugsUnit;
    }

    public void setDrugsUnit(String drugsUnit) {
        DrugsUnit = drugsUnit;
    }

    public String getDrugUsage() {
        return DrugUsage;
    }

    public void setDrugUsage(String drugUsage) {
        DrugUsage = drugUsage;
    }

    public String getDrugsPrice() {
        return DrugsPrice;
    }

    public void setDrugsPrice(String drugsPrice) {
        DrugsPrice = drugsPrice;
    }
}
